Works in python3 (maybe 2) 
Made by Mqrshie
The player Turpz, PvP and enrsww will always show up (I dont know why)
Have fun with this program!